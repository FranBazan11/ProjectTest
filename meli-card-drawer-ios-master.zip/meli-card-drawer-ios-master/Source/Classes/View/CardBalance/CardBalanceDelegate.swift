//
//  CardBalanceDelegate.swift
//  MLCardDrawer
//
//  Created by Matheus Cavalcante Teixeira on 30/06/22.
//

import Foundation

public protocol CardBalanceDelegate{
    func toggleBalance() -> Bool
}
