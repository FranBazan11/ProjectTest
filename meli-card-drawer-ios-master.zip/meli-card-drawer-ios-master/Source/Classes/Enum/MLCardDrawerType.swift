//
//  MLCardDrawerType.swift
//  MLCardDrawer
//
//  Created by Jonatan Urquiza on 7/18/19.
//

import Foundation

@objc public enum MLCardDrawerType: Int {
    case small, medium, large
}
