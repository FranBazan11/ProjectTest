import Foundation
import MLCardDrawer

// Example - CardDataHandler
@objc class CardDataHandler: NSObject, CardData {
    var name = "NOMBRE Y APELLIDO"
    var number = ""
    var securityCode = ""
    var expiration = "MM/AA"
}
