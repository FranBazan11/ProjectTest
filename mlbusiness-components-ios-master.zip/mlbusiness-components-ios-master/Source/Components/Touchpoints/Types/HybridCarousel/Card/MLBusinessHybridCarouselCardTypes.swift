//
//  MLBusinessHybridCarouselCardTypes.swift
//  MLBusinessComponents
//
//  Created by Vicente Veltri on 04/08/2020.
//

import Foundation

struct MLBusinessHybridCarouselCardTypes {
    public static let defaultType = "DEFAULT"
    public static let viewMoreType = "VIEW_MORE"
}
