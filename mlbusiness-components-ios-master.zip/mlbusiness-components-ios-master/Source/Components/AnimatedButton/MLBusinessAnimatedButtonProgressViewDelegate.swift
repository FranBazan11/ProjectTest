//
//  MLBusinessAnimatedButtonProgressViewDelegate.swift
//  MLBusinessComponents
//
//  Created by Javier Quiles on 07/11/2019.
//

import Foundation

protocol MLBusinessAnimatedButtonProgressViewDelegate: NSObjectProtocol {
    func progressViewTimeOut()
}
